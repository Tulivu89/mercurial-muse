import express from 'express';
import request from 'supertest';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { loadConfig } from '../server/config';
import type { DatabasePool } from '../server/db';
import { credentialKey, openCredential, sealCredential } from '../server/provider-settings';
import type { SettingsStore } from '../server/settings';
import { createSpeculusGenerationRouter, createSpeculusLaunchRouter } from '../server/speculus';

const encryptionKey = Buffer.alloc(32, 7).toString('base64');
const userId = '11111111-1111-4111-8111-111111111111';
const assetId = '22222222-2222-4222-8222-222222222222';
const personaId = '55555555-5555-4555-8555-555555555555';
const relatedPlaceId = '44444444-4444-4444-8444-444444444444';
const updatedAt = '2026-09-07T20:00:00.000Z';
const config = loadConfig({
  NODE_ENV: 'test', APP_ORIGIN: 'http://localhost:5174', DATABASE_URL: 'postgres://test',
  SESSION_SECRET: 'speculus-bridge-test-secret-long-enough', DISCORD_CLIENT_ID: 'client',
  DISCORD_CLIENT_SECRET: 'secret', DISCORD_REDIRECT_URI: 'http://localhost:5174/api/auth/discord/callback',
  ORBIS_CREDENTIAL_ENCRYPTION_KEY: encryptionKey, SPECULUS_BRIDGE_URL: 'http://127.0.0.1:8790',
  SPECULUS_BRIDGE_SECRET: 'shared-test-bridge-secret',
});
const settingsStore = { getEffective: async () => ({}) } as SettingsStore;

function withSession(app: express.Express, canViewAdult = true) {
  app.use((req, _res, next) => {
    Object.defineProperty(req, 'session', { value: {
      userId, discordUserId: '999999999999999999',
      access: { isGuildMember: true, canViewAdult, canCreate: false, canAdmin: false, checkedAt: Date.now() },
    }, configurable: true });
    next();
  });
}

afterEach(() => { vi.restoreAllMocks(); vi.unstubAllGlobals(); });

describe('Speculus security bridge', () => {
  it('encrypts provider credentials with authenticated encryption', () => {
    const key = credentialKey(encryptionKey);
    const sealed = sealCredential('novelai-secret-token', key);
    expect(sealed.ciphertext.toString()).not.toContain('novelai-secret-token');
    expect(openCredential(sealed, key)).toBe('novelai-secret-token');
    expect(() => openCredential(sealed, Buffer.alloc(32, 8))).toThrow();
  });

  it('boxes a record for V4 and deposits only an opaque grant via /api/v4/launch', async () => {
    const captured: { body?: Record<string, unknown>; authorization?: string; url?: string } = {};
    vi.stubGlobal('fetch', vi.fn(async (url: string | URL | Request, init?: RequestInit) => {
      captured.url = String(url);
      captured.body = JSON.parse(String(init?.body));
      captured.authorization = new Headers(init?.headers).get('authorization') ?? undefined;
      return new Response(JSON.stringify({ launchUrl: 'https://spec.thehowlingwhispers.com/v4?launch=v4-code' }), { status: 201, headers: { 'Content-Type': 'application/json' } });
    }));
    const pool = { query: vi.fn(async (sql: string) => {
      if (sql.includes('FROM library_assets a') && sql.includes('WHERE a.id')) return { rowCount: 1, rows: [{
        id: assetId, type: 'character', name: 'Ragna Holt', summary: 'A boundary warden.',
        creator_user_id: userId, content_rating: 'adult', origin_world_id: null, updated_at: updatedAt,
        tags: ['Werewolf'], document: { description: 'Terse and observant.', personality: 'Protective' },
      }] };
      if (sql.includes("WHERE id = $1 AND type = 'persona'")) return { rowCount: 1, rows: [{
        id: personaId, type: 'persona', name: 'Eirvargr', summary: 'A wandering wolf.',
        creator_user_id: userId, content_rating: 'sfw',
        document: {
          identity: { displayName: 'Eirvargr', species: 'Wolf', pronouns: 'they/them', currentLocation: 'Must not leak' },
          appearance: 'Silver-grey fur.', personality: 'Watchful.', skills: ['Tracking'],
          inventory: ['Must not leak'],
          personaSettings: { visibility: 'private', allowUse: false },
        },
      }] };
      if (sql.includes('SELECT model FROM user_provider_settings')) return { rowCount: 1, rows: [{ model: 'xialong-v1' }] };
      if (sql.includes('id <> $1')) return { rowCount: 1, rows: [{
        id: relatedPlaceId, type: 'place', name: 'Brackenjaw Enclave', summary: 'An upland settlement.',
        content_rating: 'sfw', creator_user_id: userId, origin_world_id: null, updated_at: updatedAt,
        document: {
          sourceId: 'brackenjaw-enclave', kind: 'settlement', parentLocationId: 'splitpine-reach',
          travelFromHollowmere: { referenceLocationId: 'hollowmere', distanceFromHollowmereKm: 82, estimateConfidence: 'approximate' },
          privateNarrativeField: 'should stay out of compact related asset data',
        },
      }] };
      if (sql.includes('FROM ensure_speculus_catalog_entry_v2')) return { rowCount: 1, rows: [{
        code: 'SPC-C-KD41827', prefix: 'C', plate: 'KD41827', generation: 1,
        registry_number: 1, class_registry_number: 1, classification: 'character',
        asset_created_at: updatedAt, status: 'active',
      }] };
      if (sql.includes('INSERT INTO generation_grants')) return { rowCount: 1, rows: [] };
      if (sql.startsWith('SELECT adult_access_override FROM users')) return { rows: [{ adult_access_override: false }], rowCount: 1 };
      throw new Error(`Unexpected query: ${sql}`);
    }) } as unknown as DatabasePool;
    const app = express(); app.use(express.json()); withSession(app);
    app.use('/api/v1/library', createSpeculusLaunchRouter(config, pool, settingsStore));

    const response = await request(app).post(`/api/v1/library/assets/${assetId}/simulate`).send({ personaId }).expect(201);
    expect(response.body.launchUrl).toContain('spec.thehowlingwhispers.com');
    expect(response.body.launchUrl).toContain('/v4?launch=');
    expect(response.body.launchUrl).not.toContain('/v2');
    expect(captured.authorization).toBe('Bearer shared-test-bridge-secret');
    expect(captured.body).toMatchObject({
      version: 2, engine: 'v2', model: 'xialong-v1',
      primaryAsset: { id: assetId, type: 'character', revision: updatedAt },
      catalog: { code: 'SPC-C-KD41827', classification: 'character' },
      persona: {
        id: personaId,
        name: 'Eirvargr',
        document: {
          identity: { displayName: 'Eirvargr', species: 'Wolf', pronouns: 'they/them' },
          appearance: 'Silver-grey fur.', personality: 'Watchful.', skills: ['Tracking'],
        },
      },
      character: { name: 'Ragna Holt', description: 'Terse and observant.' },
    });
    const relatedAssets = captured.body?.relatedAssets as Array<Record<string, unknown>>;
    expect(relatedAssets[0]).toMatchObject({
      id: relatedPlaceId,
      type: 'place',
      name: 'Brackenjaw Enclave',
      data: {
        sourceId: 'brackenjaw-enclave',
        parentLocationId: 'splitpine-reach',
        travelFromHollowmere: { distanceFromHollowmereKm: 82, estimateConfidence: 'approximate' },
      },
    });
    expect(JSON.stringify(relatedAssets[0])).not.toContain('privateNarrativeField');
    expect(String(captured.body?.generationGrant)).toHaveLength(43);
    expect(captured.url).toBe('http://127.0.0.1:8790/api/v4/launch');
    expect(captured.body?.engine).toBe('v2');
    expect(JSON.stringify(captured.body)).not.toContain('novelai-secret-token');
    expect(JSON.stringify(captured.body)).not.toContain('personaSettings');
    expect(JSON.stringify(captured.body)).not.toContain('Must not leak');
    expect(JSON.stringify(captured.body)).not.toContain('active Orbis user');
  });

  it('requires an explicit valid Persona id before querying the target', async () => {
    const pool = { query: vi.fn() } as unknown as DatabasePool;
    const app = express(); app.use(express.json()); withSession(app);
    app.use('/api/v1/library', createSpeculusLaunchRouter(config, pool, settingsStore));

    await request(app).post(`/api/v1/library/assets/${assetId}/simulate`).send({}).expect(400);
    // The access path reads the caller's own adult grant, so this is no longer
    // "no query at all" but the invariant that actually matters: nothing about
    // the requested asset or Persona may be touched before validation rejects.
    const queries = (pool.query as ReturnType<typeof vi.fn>).mock.calls.map(([sql]) => String(sql));
    expect(queries.filter((sql) => /library_assets|persona/i.test(sql))).toEqual([]);
  });

  it('lists only owned and directly shared allowUse Personas', async () => {
    const pool = { query: vi.fn(async (sql: string) => {
      if (sql.includes("WHERE type = 'persona'")) return { rowCount: 4, rows: [
        { id: personaId, type: 'persona', name: 'Owned', summary: '', creator_user_id: userId, content_rating: 'adult', document: {} },
        { id: '66666666-6666-4666-8666-666666666666', type: 'persona', name: 'Shared', summary: '', creator_user_id: 'other', content_rating: 'sfw', document: { personaSettings: { visibility: 'unlisted', allowUse: true } } },
        { id: '77777777-7777-4777-8777-777777777777', type: 'persona', name: 'View only', summary: '', creator_user_id: 'other', content_rating: 'sfw', document: { personaSettings: { visibility: 'public', allowUse: false } } },
        { id: '88888888-8888-4888-8888-888888888888', type: 'persona', name: 'Private', summary: '', creator_user_id: 'other', content_rating: 'sfw', document: {} },
      ] };
      if (sql.startsWith('SELECT adult_access_override FROM users')) return { rows: [{ adult_access_override: false }], rowCount: 1 };
      throw new Error(`Unexpected query: ${sql}`);
    }) } as unknown as DatabasePool;
    const app = express(); app.use(express.json()); withSession(app);
    app.use('/api/v1/library', createSpeculusLaunchRouter(config, pool, settingsStore));

    const response = await request(app).get('/api/v1/library/simulation-personas').expect(200);
    expect(response.body.items).toEqual([
      expect.objectContaining({ id: personaId, name: 'Owned', owned: true }),
      expect.objectContaining({ name: 'Shared', owned: false }),
    ]);
  });

  it('validates target access separately before looking up the selected Persona', async () => {
    const pool = { query: vi.fn(async (sql: string) => {
      if (sql.startsWith('SELECT adult_access_override')) return { rowCount: 1, rows: [{ adult_access_override: false }] };
      if (sql.includes('FROM library_assets a') && sql.includes('WHERE a.id')) return { rowCount: 1, rows: [{
        id: assetId, type: 'character', name: 'Private target', creator_user_id: 'other', content_rating: 'sfw',
        origin_world_document: { worldSettings: { visibility: 'private' } }, origin_world_creator_user_id: 'other',
      }] };
      throw new Error(`Persona query should not run: ${sql}`);
    }) } as unknown as DatabasePool;
    const app = express(); app.use(express.json()); withSession(app);
    app.use('/api/v1/library', createSpeculusLaunchRouter(config, pool, settingsStore));

    await request(app).post(`/api/v1/library/assets/${assetId}/simulate`).send({ personaId }).expect(404);
    // The target is read exactly once and the Persona lookup is never reached.
    // The other call is the access path reading the caller's own adult grant.
    const queries = (pool.query as ReturnType<typeof vi.fn>).mock.calls.map(([sql]) => String(sql));
    expect(queries.filter((sql) => /FROM library_assets a/.test(sql))).toHaveLength(1);
    expect(queries.filter((sql) => /persona/i.test(sql))).toEqual([]);
  });

  it('validates Persona existence, allowUse, and adult access independently', async () => {
    const target = {
      id: assetId, type: 'character', name: 'Target', creator_user_id: userId, content_rating: 'sfw',
      origin_world_id: null, updated_at: updatedAt, document: {},
    };
    const launchWithPersona = async (persona: Record<string, unknown> | null, canViewAdult: boolean, status: number) => {
      const pool = { query: vi.fn(async (sql: string) => {
        if (sql.includes('FROM library_assets a') && sql.includes('WHERE a.id')) return { rowCount: 1, rows: [target] };
        if (sql.includes("WHERE id = $1 AND type = 'persona'")) return { rowCount: persona ? 1 : 0, rows: persona ? [persona] : [] };
        if (sql.startsWith('SELECT adult_access_override FROM users')) return { rows: [{ adult_access_override: false }], rowCount: 1 };
        throw new Error(`Unexpected query: ${sql}`);
      }) } as unknown as DatabasePool;
      const app = express(); app.use(express.json()); withSession(app, canViewAdult);
      app.use('/api/v1/library', createSpeculusLaunchRouter(config, pool, settingsStore));
      await request(app).post(`/api/v1/library/assets/${assetId}/simulate`).send({ personaId }).expect(status);
    };

    await launchWithPersona(null, true, 404);
    await launchWithPersona({
      id: personaId, type: 'persona', name: 'View only', creator_user_id: 'other', content_rating: 'sfw',
      document: { personaSettings: { visibility: 'public', allowUse: false } },
    }, true, 403);
    await launchWithPersona({
      id: personaId, type: 'persona', name: 'Adult shared', creator_user_id: 'other', content_rating: 'adult',
      document: { personaSettings: { visibility: 'unlisted', allowUse: true } },
    }, false, 403);
  });

  it('uses the saved token only inside Orbis when redeeming a scoped grant', async () => {
    const sealed = sealCredential('novelai-secret-token', credentialKey(encryptionKey));
    let upstreamAuthorization = '';
    let upstreamBody: Record<string, unknown> = {};
    vi.stubGlobal('fetch', vi.fn(async (_url: string | URL | Request, init?: RequestInit) => {
      upstreamAuthorization = new Headers(init?.headers).get('authorization') ?? '';
      upstreamBody = JSON.parse(String(init?.body));
      return new Response(JSON.stringify({ choices: [{ text: 'The warden answers.', finish_reason: 'stop' }] }), { status: 200, headers: { 'Content-Type': 'application/json', 'x-request-id': 'nai-1' } });
    }));
    const launchId = '33333333-3333-4333-8333-333333333333';
    const pool = { query: vi.fn(async (sql: string) => {
      if (sql.includes('FROM generation_grants')) return { rowCount: 1, rows: [{
        launch_id: launchId, asset_id: assetId, asset_type: 'character', asset_revision: updatedAt, model: 'xialong-v1',
        token_ciphertext: sealed.ciphertext, token_iv: sealed.iv, token_tag: sealed.tag,
      }] };
      if (sql.startsWith('UPDATE generation_grants')) return { rowCount: 1, rows: [] };
      if (sql.startsWith('SELECT adult_access_override FROM users')) return { rows: [{ adult_access_override: false }], rowCount: 1 };
      throw new Error(`Unexpected query: ${sql}`);
    }) } as unknown as DatabasePool;
    const app = express(); app.use(express.json()); app.use('/api/v1/generation', createSpeculusGenerationRouter(config, pool));
    const response = await request(app).post('/api/v1/generation/speculus')
      .set('Authorization', 'Bearer opaque-speculus-generation-grant')
      .send({
        launchId, source: { id: assetId, revision: updatedAt, type: 'character' }, prompt: 'Continue.',
        model: 'xialong-v1', temperature: 0.85, maxTokens: 256, topK: 250, topP: 0.95,
        presencePenalty: 0.2, frequencyPenalty: 0.3, stopSequences: ['PLAYER:'],
        continueToEndOfSentence: true, reroll: false,
      })
      .expect(200);
    expect(upstreamAuthorization).toBe('Bearer novelai-secret-token');
    expect(upstreamBody).toMatchObject({
      max_tokens: 256, temperature: 0.85, top_k: 250, top_p: 0.95,
      presence_penalty: 0.2, frequency_penalty: 0.3, stream: false,
    });
    expect(upstreamBody.prompt).toContain('Complete the final sentence within the output allowance.');
    expect(upstreamBody.stop).toContain('PLAYER:');
    expect(response.body).toEqual({ text: 'The warden answers.', finishReason: 'stop' });
    expect(JSON.stringify(response.body)).not.toContain('novelai-secret-token');
    expect(response.headers['x-request-id']).toBe('nai-1');
  });
});
