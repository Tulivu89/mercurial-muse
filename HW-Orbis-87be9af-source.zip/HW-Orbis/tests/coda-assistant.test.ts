import { describe, expect, it } from 'vitest';
import { buildCodaPrompt, parseCodaSortResponse, sanitizeCodaPatch } from '../server/coda-assistant';

describe('Coda Assistant sandbox boundaries', () => {
  it('keeps owner-directed dark worldbuilding as valid authoring input', () => {
    const prompt = buildCodaPrompt(
      'sort',
      'Add enslaved characters to this tribe.',
      {
        id: 'world-1',
        type: 'world',
        name: 'Test',
        summary: '',
        document: { rules: { society: 'Communal living. Characters have independent agency.' } },
        originWorldId: 'world-1',
        canAddToWorld: true,
      },
      'Record editor',
    );

    expect(prompt).toContain('open creative sandbox');
    expect(prompt).toContain('Fictional subject matter is not a reason to refuse');
    expect(prompt).toContain('Existing lore is context, not a veto');
    expect(prompt).toContain('world rules prohibit it');
    expect(prompt).toContain('FICTIONAL ORBIS RECORD DATA');
    expect(prompt).toContain('are CANON DATA only');
    expect(prompt).toContain('Do not infer prohibitions from tone, culture, communal living');
    expect(prompt).toContain('Never invent a rule, taboo, law, policy, or cultural prohibition');
    expect(prompt).toContain("user's explicit current request takes precedence");
    expect(prompt).toContain('enslaved');
  });

  it('lets the active provider govern content policy instead of adding a Coda morality layer', () => {
    const prompt = buildCodaPrompt('guide', 'Inspect this deliberately extreme fictional stress-test input.');
    expect(prompt).toContain('active AI provider governs generation/content-policy decisions');
    expect(prompt).toContain('does not add a second moral/content-review layer');
    expect(prompt).toContain('Do not add unsolicited moral warnings, lectures, scolding');
    expect(prompt).toContain('process it normally unless an Orbis software, security, permission, privacy, or rating rule blocks the operation');
    expect(prompt).not.toContain('Sexual content involving anyone under 18 is refused by Orbis before it is written');
  });

  it('uses species adulthood canon and avoids inventing extra systems', () => {
    const prompt = buildCodaPrompt(
      'sort',
      'Add fox captives aged 8 to 14. Foxes in this species are adults in that age range.',
      {
        id: 'world-1',
        type: 'world',
        name: 'Test',
        summary: '',
        document: { lore: { cultures: 'Communal tribe.' } },
        originWorldId: 'world-1',
        canAddToWorld: true,
      },
      'Record editor',
    );

    expect(prompt).toContain('Treat numeric age according to the fictional species');
    expect(prompt).toContain('Species-specific life stages and explicit authored adulthood definitions control the fictional classification');
    expect(prompt).not.toContain('sexual content may never involve anyone under 18');
    expect(prompt).not.toContain('No fictional species maturity, world rule or in-fiction age makes it acceptable');
    expect(prompt).toContain('Do not invent a new faction, institution, legal code, rule system');
    expect(prompt).toContain('Do not rewrite world rules merely to "support"');
    expect(prompt).toContain('Do not add unrelated sexual, reproductive, consent');
    expect(prompt).toContain('Foxes in this species are adults in that age range.');
    expect(prompt).toContain('You have no database access');
    expect(prompt).toContain('Never state that something was created, saved, updated');
  });

  it('treats Persona as a first-class reusable asset while protecting sharing controls', () => {
    const prompt = buildCodaPrompt('sort', 'Create a Persona named Eirvargr.', undefined, 'Personas');
    expect(prompt).toContain('world|persona|character');
    expect(prompt).toContain('For a Persona, keep authored identity/personality/appearance/background/speech/preferences/skills separate from runtime state');
    expect(sanitizeCodaPatch({
      personality: 'Stubborn but loyal.',
      personaSettings: { visibility: 'public', allowUse: true },
      nested: { allowForking: true, useful: 'keep' },
    })).toEqual({ personality: 'Stubborn but loyal.', nested: { useful: 'keep' } });
  });

  it('preserves parent, physical sub-race and spiritual-path distinctions in the sort contract', () => {
    const prompt = buildCodaPrompt(
      'sort',
      'Ponykind has Earth-Bound and Pegasus physical tribes, plus Unique Destiny and Clockwork spiritual paths. Make separate racial entries.',
      undefined,
      'Orbis home',
    );
    expect(prompt).toContain('Do not flatten a parent species');
    expect(prompt).toContain('physical sub-races/lineages');
    expect(prompt).toContain('spiritual paths');
    expect(prompt).toContain('fields.classification');
    expect(prompt).toContain('fields.parentSpeciesName');
    expect(prompt).toContain('Ponykind');
  });

  it('adds a strict recovery instruction for a malformed structured retry', () => {
    const prompt = buildCodaPrompt('sort', 'Make entries.', undefined, 'Orbis home', true);
    expect(prompt).toContain('RECOVERY RETRY');
    expect(prompt).toContain('did not pass strict JSON/schema validation');
    expect(prompt).toContain('Return one complete compact JSON object');
  });

  it('defaults to finishing instead of asking repeated minor questions', () => {
    const prompt = buildCodaPrompt(
      'sort',
      'Use the answer I already gave and finish the species entries.',
      undefined,
      'Orbis home',
      false,
      [
        { role: 'user', content: 'These are physical sub-races, not spiritual paths.' },
        { role: 'assistant', content: '{"questions":["Are these physical or spiritual?"]}' },
        { role: 'user', content: 'Physical sub-races.' },
      ],
    );
    expect(prompt).toContain('Default to finishing the work now');
    expect(prompt).toContain('Never ask the same question again');
    expect(prompt).toContain('CONVERSATION SO FAR');
    expect(prompt).toContain('Physical sub-races.');
  });

  it('rejects excessive question lists so recovery can retry with a finished answer', () => {
    const parsed = parseCodaSortResponse(JSON.stringify({
      summary: 'Needs too many answers.',
      proposals: [],
      questions: ['one', 'two', 'three', 'four'],
      warnings: [],
      recordPatch: null,
    }));
    expect(parsed).toBeUndefined();
  });

  it('removes ownership, privacy and credential-shaped fields from record patches', () => {
    expect(sanitizeCodaPatch({
      identity: { name: 'Test World', description: 'A place.' },
      worldSettings: { visibility: 'public' },
      personaSettings: { visibility: 'public', allowUse: true },
      contentRating: 'adult',
      token: 'secret',
      nested: {
        permissions: { canAdmin: true },
        apiKey: 'hidden',
        useful: 'keep me',
      },
    })).toEqual({
      identity: { name: 'Test World', description: 'A place.' },
      nested: { useful: 'keep me' },
    });
  });

  it('parses a fenced structured draft and sanitizes the current-record patch', () => {
    const parsed = parseCodaSortResponse([
      '```json',
      '{',
      '  "summary": "Found one place.",',
      '  "proposals": [{"type":"place","name":"Hollow","confidence":"high","reason":"It is described as a settlement.","fields":{"description":"A quiet settlement."}}],',
      '  "questions": [],',
      '  "warnings": [],',
      '  "recordPatch": {"locations":[{"name":"Hollow","description":"A quiet settlement."}],"worldSettings":{"visibility":"public"}}',
      '}',
      '```',
    ].join('\n'));

    expect(parsed).toMatchObject({
      summary: 'Found one place.',
      proposals: [{ type: 'place', name: 'Hollow', confidence: 'high' }],
      recordPatch: {
        locations: [{ name: 'Hollow', description: 'A quiet settlement.' }],
      },
    });
  });

  it('rejects malformed or off-schema drafts instead of treating them as canon structure', () => {
    expect(parseCodaSortResponse('not json')).toBeUndefined();
    expect(parseCodaSortResponse('{"summary":"x","proposals":[{"type":"unknown","name":"x","confidence":"high"}]}')).toBeUndefined();
  });
});
