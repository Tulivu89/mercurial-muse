// Scene: where you are, the time, who and what is here, and what you can do.
import { useState } from 'react';
import {
  band, bondBetween, calendarOf, canLoot, carried, coinOf, datePhrase, bringAlong, definite, doingNow, dueElsewhere, durationWords, fact, followRuleFor, followingAs, leaveBehind, labelFor, line, offerFor, shortLabel, pairName, playerOf, read, sceneActionsFor, sceneOf, stallsHere, stateDefFor,
  stateTestFor, timeOfDay, weekdayOf, whereabouts, type Character, type Item, type StateDef,
} from '../engine';
import { BondWithYou } from './Bonds';
import type { PlayApi } from './Play';
import { ChevronRight, LockIcon, SkipIcon } from './icons';
import { DraftTag, StateBar, YoursTag, characterStates, goodWords, groupsOf, initials, roleOf, speciesOf, stateColor } from './shared';
import { ValueEditor } from './ValueEditor';

export function SceneSection({ api }: { api: PlayApi }) {
  const { world, save, prefs, busy } = api;
  const scene = sceneOf(world, save);
  const calendar = calendarOf(world);
  const weekday = weekdayOf(calendar, save.clock);
  const date = [weekday >= 0 ? calendar.dayNames[weekday] : '', datePhrase(calendar, save.clock)].filter(Boolean).join(' ');
  const parent = scene.place.parentLocationId ? world.world.places.find((place) => place.id === scene.place.parentLocationId) : undefined;
  const placeStates = world.ruleset.states.filter((def) => def.scope === 'place' && def.display !== 'hidden');
  const actions = sceneActionsFor(world, save);
  const [waitOther, setWaitOther] = useState('');

  return (
    <>
      <div className="card pad">
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <p className="label" style={{ flex: 1 }}>{[scene.place.kind !== 'other' ? scene.place.kind : '', parent?.name].filter(Boolean).join(' · ')}</p>
          <DraftTag record={scene.place} show={prefs.showDrafts} />
          <YoursTag record={scene.place} />
        </div>
        <h3 style={{ margin: '8px 0 6px', font: '600 26px/1.15 var(--read)' }}>{scene.place.name}</h3>
        {scene.place.description && <p className="prose" style={{ fontSize: 16 }}>{scene.place.description}</p>}
        <div className="facts-grid">
          <div className="fact">
            <p className="label">Time</p>
            <p className="big">{timeOfDay(save.clock)}</p>
            <p className="meta">{capitalise(scene.timeBand)}{date ? `, ${date}` : ''}</p>
          </div>
          {placeStates.map((def) => {
            const value = read(save.values, def, scene.place.id);
            const reading = band(def, value);
            return (
              <div key={def.id} className="fact">
                <p className="label">{def.name}</p>
                <p className="big word">{reading.banded ? reading.short : value}</p>
                {prefs.showNumbers && <p className="meta">{value} of {Math.max(def.min, def.max)}</p>}
              </div>
            );
          })}
        </div>
      </div>

      <div className="sub"><p className="label">People here</p><span className="meta">{scene.present.length || 'none'}</span></div>
      {scene.present.length ? (
        <div className="card clip rows">
          {scene.present.map((person, index) => <PersonRow key={person.id} api={api} person={person} open={index === 0 && scene.present.length === 1} />)}
        </div>
      ) : (
        <div className="card pad"><p className="meta">Nobody else is here.</p></div>
      )}

      <div className="sub"><p className="label">Things here</p><span className="meta">{scene.things.length || 'none recorded'}</span></div>
      <div className="card clip rows">
        {scene.things.map((thing) => <ThingRow key={thing.id} api={api} thing={thing} />)}
        <div className="lr" style={{ paddingTop: 14, paddingBottom: 14 }}>
          <p className="grow meta" style={{ lineHeight: 1.45, color: 'var(--text-2)' }}>
            {scene.things.length ? 'Add anything else the story brings in.' : 'Things the story mentions are only description until you add them. Add one and it stays with your story.'}
          </p>
          <button type="button" className="btn" onClick={() => api.editRecord({ mode: 'new', type: 'thing', locationId: scene.place.id })}>Add</button>
        </div>
      </div>

      <div className="sub"><p className="label">What you can do</p></div>
      <div className="card">
        {actions.map((action) => (
          <div key={action.id} className="lr">
            <span className="grow">
              <span className="name" style={{ display: 'block' }}>{action.name}</span>
              {action.summary && <span className="meta" style={{ display: 'block', marginTop: 2 }}>{action.summary}</span>}
            </span>
            <button type="button" className="btn primary" disabled={busy} onClick={() => api.perform({ type: 'scene', actionId: action.id })}>Do it</button>
          </div>
        ))}
        {world.ruleset.approaches.length > 0 && (
          <div className="lr">
            <span className="grow">
              <span className="name" style={{ display: 'block' }}>Make a check</span>
              <span className="meta" style={{ display: 'block', marginTop: 2 }}>Roll for something uncertain, or let it succeed.</span>
            </span>
            <button type="button" className="btn" disabled={busy} onClick={() => api.openCheck()}>Choose</button>
          </div>
        )}
        <div className="lr stack">
          <span className="name">Wait</span>
          <div className="seg" role="group" aria-label="Wait for">
            {([[10, '10 min'], [60, '1 hour'], [240, '4 hours']] as const).map(([minutes, label]) => (
              <button key={minutes} type="button" disabled={busy} onClick={() => api.perform({ type: 'wait', minutes })}>{label}</button>
            ))}
          </div>
          <form
            style={{ display: 'flex', gap: 8 }}
            onSubmit={(event) => {
              event.preventDefault();
              const minutes = Math.round(Number(waitOther));
              if (minutes > 0) { api.perform({ type: 'wait', minutes }); setWaitOther(''); }
            }}
          >
            <label htmlFor="wait-other" className="sr">Minutes to wait</label>
            <input id="wait-other" className="field" inputMode="numeric" placeholder="Or a number of minutes" value={waitOther} onChange={(event) => setWaitOther(event.target.value.replace(/[^\d]/g, ''))} />
            <button type="submit" className="btn" disabled={busy || !waitOther}>Wait</button>
            <button
              type="button"
              className="btn quiet square"
              aria-label="Wait quietly"
              title="Wait quietly: the clock moves, nothing is written"
              disabled={busy || !waitOther}
              onClick={() => {
                const minutes = Math.round(Number(waitOther));
                if (minutes > 0) { api.performQuietly({ type: 'wait', minutes }); setWaitOther(''); }
              }}
            ><SkipIcon /></button>
          </form>
          <span className="meta" style={{ display: 'flex', gap: 6, alignItems: 'flex-start', lineHeight: 1.4 }}><span style={{ flex: 'none', display: 'inline-flex' }}><SkipIcon /></span><span>Waits or goes quietly: the rules move the clock or you, and nothing is written. For when the story has drifted.</span></span>
        </div>
      </div>

      <div className="sub"><p className="label">Ways out</p><button type="button" className="link" onClick={() => api.open('menu', 'map')}>Open the map</button></div>
      <div className="card">
        {scene.exits.length === 0 && <div className="lr"><span className="meta">No known way out.</span></div>}
        {scene.exits.map((exit) => (
          <div key={`${exit.edge.kind}:${exit.edge.routeId ?? exit.place.id}`} className="lr" style={exit.blocked ? { alignItems: 'flex-start' } : undefined}>
            {exit.blocked && <span style={{ color: 'var(--bad)', marginTop: 2 }}><LockIcon size={18} /></span>}
            <span className="grow">
              <span className="name" style={{ display: 'block' }}>{exit.place.name}</span>
              {exit.blocked && <span style={{ display: 'block', marginTop: 3, fontSize: 14, lineHeight: 1.4, color: 'var(--text-2)' }}>{exit.blocked}</span>}
            </span>
            <span className="mono meta">{durationWords(exit.edge.minutes)}</span>
            {!exit.blocked && <button type="button" className="btn quiet square" aria-label={`Go quietly to ${exit.place.name}`} title="Go quietly: you move, nothing is written" disabled={busy} onClick={() => api.performQuietly({ type: 'travel', to: exit.place.id })}><SkipIcon /></button>}
            {!exit.blocked && <button type="button" className="btn" disabled={busy} onClick={() => api.perform({ type: 'travel', to: exit.place.id })}>Go</button>}
          </div>
        ))}
      </div>
    </>
  );
}

function capitalise(text: string): string {
  return text ? text.charAt(0).toUpperCase() + text.slice(1) : text;
}

function PersonRow({ api, person, open }: { api: PlayApi; person: Character; open: boolean }) {
  const { world, save, prefs } = api;
  const defs = characterStates(world, person, false);
  const offRest = defs
    .map((def) => ({ def, value: read(save.values, def, person.id) }))
    .map((entry) => ({ ...entry, reading: band(entry.def, entry.value) }))
    .filter((entry) => entry.reading.banded && !entry.reading.atRest);
  // In other people's words, as the narrator reads them: "is wavering", not "is strained".
  const theirs = (def: StateDef, value: number) => shortLabel(def, labelFor(def, value, false));
  const knows = defs.map((def) => fact(stateDefFor(world, def.id, person.id) ?? def, definite(person.name), read(save.values, def, person.id))).filter(Boolean);
  const meta = [roleOf(person), speciesOf(world, person), ...groupsOf(world, person)].filter(Boolean).join(' · ');
  const local = person.origin === 'local';
  const doing = doingNow(world, save, person);
  const day = doing ? whereabouts(calendarOf(world), person, save.clock, stateTestFor(world, save.values)) : null;
  const due = dueElsewhere(world, save, person);
  const as = followingAs(world, save, person.id);
  const rule = as ? null : followRuleFor(world, save, person.id);
  const name = person.name.replace(/^(The|A|An) /, (word) => word.toLowerCase());
  const follow = (byHand: boolean) => {
    const result = bringAlong(api.module, save, person.id, byHand);
    if (result.ok) api.commit(result.save, `${person.name} will come with you when you travel.`); else api.notify(result.reason);
  };
  const stay = () => {
    const result = leaveBehind(api.module, save, person.id);
    if (result.ok) api.commit(result.save, `${person.name} will stay here when you go.`); else api.notify(result.reason);
  };
  const dossier = ([['Looks', person.appearance], ['Manner', person.personality], ['Speech', person.speech]] as [string, string | undefined][])
    .filter((entry): entry is [string, string] => typeof entry[1] === 'string' && entry[1].trim() !== '');
  // Their ties to the others here, and the bond with you, as the narrator reads them.
  const playerId = playerOf(world);
  const ties = sceneOf(world, save).present
    .filter((other) => other.id !== person.id)
    .map((other) => bondBetween(world, save, person.id, other.id))
    .filter((bond) => bond !== null);
  const withYou = bondBetween(world, save, playerId, person.id);
  const bondFact = withYou?.def ? line({ ...withYou.def, line: withYou.def.line ?? '[|name|: |bandLabel|]' }, pairName(world, withYou.owner, playerId), withYou.value) : '';

  return (
    <details open={open}>
      <summary className="row">
        <span className={`av${local ? ' yours' : ''}`} aria-hidden="true">{initials(person.name)}</span>
        <span className="row-text">
          <span className="name">{person.name}</span>
          {meta && <span className="meta">{meta}</span>}
        </span>
        {offRest.slice(0, 2).map(({ def, value }) => (
          <span key={def.id} className="pill"><span className="dot" style={{ background: stateColor(def) }} /><span className="pill-text">{theirs(def, value).replace(/^(is|has) /, '')}</span></span>
        ))}
        {as && <span className="tag yours">With you</span>}
        <DraftTag record={person} show={prefs.showDrafts} />
        <ChevronRight />
      </summary>
      <div className="row-body">
        {person.description && <p className="prose">{person.description}</p>}
        {doing && (
          <p className="meta" style={{ lineHeight: 1.45, color: 'var(--text-2)' }}>
            Now {doing}{day ? `, until ${timeOfDay(day.until)}` : ''}.
          </p>
        )}
        {due && (
          <p className="meta" style={{ lineHeight: 1.45, color: 'var(--text-2)' }}>
            Staying while you are here. Due at {due.replace(/^The /, 'the ')} by now.
          </p>
        )}
        {as && (
          <div className="knows">
            <p className="label">With you</p>
            <p className="prose-strong" style={{ marginTop: 6, fontSize: 15 }}>{as.charAt(0).toUpperCase()}{as.slice(1)}. Comes wherever you go and keeps no schedule.</p>
            <button type="button" className="btn" style={{ marginTop: 10 }} onClick={stay}>Leave {name} here</button>
          </div>
        )}
        {dossier.length > 0 && (
          <dl className="dossier">
            {dossier.map(([label, text]) => (
              <div key={label}><dt>{label}</dt><dd>{text}</dd></div>
            ))}
          </dl>
        )}
        {ties.map((tie) => (
          <p key={tie.relationship.id} className="meta" style={{ lineHeight: 1.45, color: 'var(--text-2)' }}>
            <b style={{ color: 'var(--text)' }}>With {tie.other.name.replace(/^The /, 'the ').replace(/^A /, 'a ')}:</b> {[tie.def?.name, tie.tier].filter(Boolean).join('. ')}
          </p>
        ))}
        {defs.filter((def) => def.bands.length).length > 0 && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {defs.filter((def) => def.bands.length).map((def) => {
              const value = read(save.values, def, person.id);
              return (
                <div key={def.id} className="state-line">
                  <span className="what">{def.name}</span>
                  <StateBar def={def} value={value} />
                  <span className="word">{theirs(def, value)}{prefs.showNumbers ? ` · ${value}` : ''}</span>
                </div>
              );
            })}
          </div>
        )}
        <div className="knows">
          <p className="label">The narrator knows</p>
          <p className="facts">{[...knows, bondFact, as ? `With you: ${as}.` : due ? `Due at ${due.replace(/^The /, 'the ')} by now.` : doing ? `Now: ${doing}.` : ''].filter(Boolean).join(' ') || 'Only their description: nothing about them is out of the ordinary.'}</p>
        </div>
        <BondWithYou api={api} person={person} />
        <TradeWith api={api} person={person} />
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <button type="button" className="btn" style={{ flex: 1 }} onClick={() => api.talkTo(person.name)}>Talk to them</button>
          {world.ruleset.approaches.length > 0 && (
            <button type="button" className="btn" style={{ flex: 1 }} onClick={() => api.openCheck(person.id)}>Make a check</button>
          )}
          {rule && <button type="button" className="btn" style={{ flex: 1 }} onClick={() => follow(false)}>{rule.label}</button>}
          <button type="button" className="btn quiet" onClick={() => api.lookUp(person.name)}>Look up</button>
          {local && <button type="button" className="btn quiet" onClick={() => api.editRecord({ mode: 'edit', id: person.id })}>Edit</button>}
        </div>
        {defs.length > 0 && (
          <details>
            <summary className="meta" style={{ textDecoration: 'underline', textUnderlineOffset: 3 }}>Set their values by hand</summary>
            <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 10 }}>
              {defs.map((def) => <ValueEditor key={def.id} def={def} value={read(save.values, def, person.id)} onSet={(value) => api.setValue(def.id, person.id, value)} />)}
              {!as && !rule && <button type="button" className="btn" onClick={() => follow(true)}>Bring {name} along anyway</button>}
            </div>
          </details>
        )}
      </div>
    </details>
  );
}

// What you can buy from someone here and sell to them, and what you can take from them
// once they are down or have given way. Each is a turn the rules settle.
function TradeWith({ api, person }: { api: PlayApi; person: Character }) {
  const { world, save, busy } = api;
  const stall = stallsHere(world, save).find((entry) => entry.seller.id === person.id);
  const lootable = canLoot(world, save, person.id);
  if (!stall && !lootable) return null;
  const coin = coinOf(world, save);
  const yours = stall ? carried(world, save) : [];
  const name = person.name.replace(/^(The|A|An) /, (word) => word.toLowerCase());
  return (
    <div className="knows">
      {stall && (
        <>
          <p className="label">Sells · you have {coin} coin</p>
          {stall.refusing && <p className="meta" style={{ marginTop: 6 }}>Won’t deal with you today.</p>}
          {stall.bargain > 0 && <p className="meta" style={{ marginTop: 6 }}>Your bargain: {stall.bargain === 1 ? 'a quarter' : 'half'} off your next purchase.</p>}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 8 }}>
            {stall.goods.map(({ good, price }) => (
              <div key={good.id} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ flex: 1, fontSize: 15 }}>{good.name.replace(/^(a|an) /, '')}<span className="meta"> · {goodWords(good)}</span></span>
                <span className="mono meta">{price}{price !== good.worth ? ` (${good.worth})` : ''}</span>
                <button type="button" className="btn small" disabled={busy || stall.refusing || coin < price} onClick={() => api.perform({ type: 'buy', from: person.id, goodId: good.id })}>Buy</button>
              </div>
            ))}
          </div>
          {yours.length > 0 && !stall.refusing && (
            <details style={{ marginTop: 8 }}>
              <summary className="meta" style={{ textDecoration: 'underline', textUnderlineOffset: 3 }}>Sell to {name}</summary>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 8 }}>
                {yours.map(({ good, count }) => (
                  <div key={good.id} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span style={{ flex: 1, fontSize: 15 }}>{good.name.replace(/^(a|an) /, '')}{count > 1 ? ` ×${count}` : ''}</span>
                    <span className="mono meta">{offerFor(world, person.id, good)}</span>
                    <button type="button" className="btn small" disabled={busy} onClick={() => api.perform({ type: 'sell', to: person.id, goodId: good.id })}>Sell</button>
                  </div>
                ))}
              </div>
            </details>
          )}
        </>
      )}
      {lootable && (
        <button type="button" className="btn" style={{ marginTop: stall ? 10 : 0 }} disabled={busy} onClick={() => api.perform({ type: 'loot', from: person.id })}>Take what {name} carries</button>
      )}
    </div>
  );
}

// A thing here: what it is, what state it is in, and a check against it.
function ThingRow({ api, thing }: { api: PlayApi; thing: Item }) {
  const { world, save, prefs } = api;
  const defs = world.ruleset.states.filter((def) => def.scope === 'item' && def.bands.length && def.display !== 'hidden');
  const offRest = defs
    .map((def) => ({ def, value: read(save.values, def, thing.id) }))
    .map((entry) => ({ ...entry, reading: band(entry.def, entry.value) }))
    .filter((entry) => !entry.reading.atRest);
  const local = thing.origin === 'local';
  return (
    <details>
      <summary className="row">
        <span className="av place" aria-hidden="true">{initials(thing.name)}</span>
        <span className="row-text"><span className="name">{thing.name}</span>{typeof thing.summary === 'string' && thing.summary && <span className="meta">{thing.summary}</span>}</span>
        {offRest.slice(0, 2).map(({ def, reading }) => (
          <span key={def.id} className="pill"><span className="dot" style={{ background: stateColor(def) }} />{reading.short.replace(/^is /, '')}</span>
        ))}
        <YoursTag record={thing} />
        <ChevronRight />
      </summary>
      <div className="row-body">
        {thing.description && <p className="prose">{thing.description}</p>}
        {offRest.length > 0 && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {offRest.map(({ def, value, reading }) => (
              <div key={def.id} className="state-line">
                <span className="what">{def.name}</span>
                <StateBar def={def} value={value} />
                <span className="word">{reading.short}{prefs.showNumbers ? ` · ${value}` : ''}</span>
              </div>
            ))}
          </div>
        )}
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          {world.ruleset.approaches.length > 0 && <button type="button" className="btn" style={{ flex: 1 }} onClick={() => api.openCheck(thing.id)}>Make a check</button>}
          {local && <button type="button" className="btn quiet" onClick={() => api.editRecord({ mode: 'edit', id: thing.id })}>Edit</button>}
        </div>
        {defs.length > 0 && (
          <details>
            <summary className="meta" style={{ textDecoration: 'underline', textUnderlineOffset: 3 }}>Set its values by hand</summary>
            <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 10 }}>
              {defs.map((def) => <ValueEditor key={def.id} def={def} value={read(save.values, def, thing.id)} onSet={(value) => api.setValue(def.id, thing.id, value)} />)}
            </div>
          </details>
        )}
      </div>
    </details>
  );
}
